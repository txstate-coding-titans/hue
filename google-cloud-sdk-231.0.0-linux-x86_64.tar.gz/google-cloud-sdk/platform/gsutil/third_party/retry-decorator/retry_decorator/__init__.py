# -*- coding: utf-8 -*-

from .retry_decorator import *

__title__ = 'retry_decorator'
__version__ = "1.0.0"
